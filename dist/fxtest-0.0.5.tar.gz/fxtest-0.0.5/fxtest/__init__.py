from fxtest.testdata.data import main
from fxtest.webdriver import WebDriver
from fxtest.testdata.case import TestCase


__version__ = "0.0.5"