
class Fxtest:
    driver = None
    timeout = None

class BrowserConfig:
    """
    Define run browser config
    """
    name = None
    driver_path = None
    grid_url = None
    report_path = None
    allure_path =None
    proxy = None
